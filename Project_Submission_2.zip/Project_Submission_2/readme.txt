List of sites used as reference material :
1)
Finding the index of an item given a list containing it in Python - http://bit.ly/2IaNmfJ

2)
Python add leading zeroes using str.format - http://bit.ly/2I5ur5V

3)
Pandas DataFrame Groupby two columns and get counts - http://bit.ly/2JMt7SI

4)
Convert seconds to hours/minutes/seconds and pretty print - http://bit.ly/2HJmns5

5)
How to convert rows in DataFrame in Python to dictionaries - http://bit.ly/2wbov6R
