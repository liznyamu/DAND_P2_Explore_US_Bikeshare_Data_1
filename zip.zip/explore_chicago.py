import pandas as pd

df = pd.read_csv("chicago.csv")
print(df.head())  # start by viewing the first few rows of the dataset!