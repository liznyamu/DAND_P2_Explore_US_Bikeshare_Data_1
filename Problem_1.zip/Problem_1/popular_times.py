import pandas as pd

filename = 'chicago.csv'

# load data file into a dataframe
df = 

# convert the Start Time column to datetime
df['Start Time'] =

# extract hour from the Start Time column to create an hour column
df['hour'] =

# find the most common hour (from 0 to 23)
popular_hour = 
    
print('Most Frequent Start Hour:', popular_hour)
