import pandas as pd

filename = 'chicago.csv'

# load data file into a dataframe
df = 

# print value counts for each user type
user_types = 

print(user_types)